# Fichier : core/models.py - Version Corrigée et Complète

from django.db import models
from django.contrib.auth.models import User
from django.conf import settings
from django.utils import timezone
import uuid

# ==============================================================================
# AXE 0 : GESTION DES UTILISATEURS & COMPÉTENCES
# ==============================================================================

class ProfilUtilisateur(models.Model):
    ROLE_CHOIX = [
        ('ADMIN', 'Administrateur'),
        ('MANAGER', 'Manager'),
        ('TECHNICIEN', 'Technicien'),
        ('OPERATEUR', 'Opérateur'),
        ('SUPERVISEUR', 'Superviseur'),
    ]
    
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='profil')
    telephone = models.CharField(max_length=20, blank=True, null=True)
    role = models.CharField(max_length=20, choices=ROLE_CHOIX, default='OPERATEUR')
    
    def __str__(self):
        return f"{self.user.username} ({self.role})"

class Competence(models.Model):
    nom = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True, null=True)
    
    def __str__(self):
        return self.nom

class UtilisateurCompetence(models.Model):
    utilisateur = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    competence = models.ForeignKey(Competence, on_delete=models.CASCADE)
    niveau = models.PositiveIntegerField(choices=[(1, 'Débutant'), (2, 'Intermédiaire'), (3, 'Expert')], default=1)
    date_obtention = models.DateField(default=timezone.now)
    
    class Meta:
        unique_together = ('utilisateur', 'competence')
    
    def __str__(self):
        return f"{self.utilisateur.username} - {self.competence.nom} (Niveau {self.niveau})"

class Equipe(models.Model):
    nom = models.CharField(max_length=100, unique=True)
    chef_equipe = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='equipes_dirigees')
    membres = models.ManyToManyField(settings.AUTH_USER_MODEL, related_name='equipes')
    
    def __str__(self):
        return self.nom

# ==============================================================================
# AXE 1 : GESTION DES ACTIFS (ASSETS) & LEURS DONNÉES DYNAMIQUES
# ==============================================================================

class CategorieAsset(models.Model):
    nom = models.CharField(max_length=100, unique=True)
    
    def __str__(self):
        return self.nom

class Asset(models.Model):
    STATUT_ASSET_CHOIX = [
        ('EN_SERVICE', 'En service'), 
        ('EN_PANNE', 'En panne'), 
        ('EN_MAINTENANCE', 'En maintenance'), 
        ('HORS_SERVICE', 'Hors service')
    ]
    
    nom = models.CharField(max_length=255)
    reference = models.CharField(max_length=100, blank=True, null=True)
    categorie = models.ForeignKey(CategorieAsset, on_delete=models.SET_NULL, null=True, blank=True)
    parent = models.ForeignKey('self', on_delete=models.SET_NULL, null=True, blank=True, related_name='enfants')
    marque = models.CharField(max_length=100, blank=True, null=True)
    modele = models.CharField(max_length=100, blank=True, null=True)
    date_achat = models.DateField(null=True, blank=True)
    date_mise_en_service = models.DateField(null=True, blank=True)
    fin_garantie = models.DateField(null=True, blank=True)
    statut = models.CharField(max_length=20, choices=STATUT_ASSET_CHOIX, default='EN_SERVICE')
    criticite = models.PositiveIntegerField(choices=[(1, 'Basse'), (2, 'Moyenne'), (3, 'Haute'), (4, 'Critique')], default=2)
    localisation_texte = models.CharField(max_length=255, blank=True, null=True)
    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    photo_principale = models.ImageField(upload_to='asset_photos/', null=True, blank=True)
    qr_code_identifier = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    
    def __str__(self):
        return f"{self.nom} ({self.reference or 'N/A'})"

class AttributPersonnaliseAsset(models.Model):
    asset = models.ForeignKey(Asset, on_delete=models.CASCADE, related_name='attributs_perso')
    cle = models.CharField(max_length=100, help_text="Nom du champ personnalisé. Ex: 'Couleur RAL'")
    valeur = models.CharField(max_length=255, help_text="Valeur du champ. Ex: '5015'")
    
    class Meta:
        unique_together = ('asset', 'cle')
    
    def __str__(self):
        return f"{self.asset.nom} | {self.cle}: {self.valeur}"

# ==============================================================================
# AXE 2 : GESTION DES STOCKS & PIÈCES DÉTACHÉES
# ==============================================================================

class PieceDetachee(models.Model):
    reference = models.CharField(max_length=100, unique=True)
    nom = models.CharField(max_length=255)
    stock_actuel = models.PositiveIntegerField(default=0)
    seuil_alerte_stock = models.PositiveIntegerField(default=0, help_text="Le système alertera si le stock passe sous ce seuil.")
    cout_unitaire = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    
    def __str__(self):
        return f"{self.nom} ({self.reference})"

# ==============================================================================
# AXE 3 : GESTION DES GAMMES DE MAINTENANCE (TEMPLATES)
# ==============================================================================

class Intervention(models.Model):
    STATUT_CHOIX = [
        ('DRAFT', 'Brouillon'),
        ('VALIDATED', 'Validé'),
        ('ARCHIVED', 'Archivé'),
    ]
    
    nom = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True, help_text="Décrivez l'objectif général de cette intervention.")
    statut = models.CharField(max_length=20, choices=STATUT_CHOIX, default='DRAFT')
    duree_estimee_heures = models.PositiveIntegerField(default=1, help_text="Durée estimée de l'intervention en heures.")
    techniciens_requis = models.PositiveIntegerField(default=1, help_text="Nombre de techniciens nécessaires.")
    competences_requises = models.ManyToManyField(Competence, blank=True, help_text="Compétences suggérées pour réaliser cette intervention.")
    pieces_necessaires = models.ManyToManyField(PieceDetachee, blank=True, help_text="Nomenclature des pièces habituellement nécessaires.")
    
    def __str__(self):
        return self.nom

class Operation(models.Model):
    intervention = models.ForeignKey(Intervention, on_delete=models.CASCADE, related_name='operations')
    nom = models.CharField(max_length=255)
    ordre = models.PositiveIntegerField(default=1)
    
    class Meta:
        ordering = ['ordre']
        unique_together = ('intervention', 'ordre')
    
    def __str__(self):
        return f"{self.intervention.nom} | Étape {self.ordre}: {self.nom}"

class PointDeControle(models.Model):
    TYPE_CHAMP_CHOIX = [
        ('TEXT', 'Texte libre'),
        ('NUMBER', 'Nombre'),
        ('BOOLEAN', 'Oui/Non'),
        ('SELECT', 'Liste de choix'),
        ('TEXTAREA', 'Zone de texte'),
        ('DATE', 'Date'),
        ('TIME', 'Heure'),
        ('DATETIME', 'Date et heure'),
    ]
    
    operation = models.ForeignKey(Operation, on_delete=models.CASCADE, related_name='points_de_controle')
    label = models.CharField(max_length=255)
    type_champ = models.CharField(max_length=20, choices=TYPE_CHAMP_CHOIX, default='TEXT')
    aide = models.TextField(blank=True, null=True, help_text="Instructions pour l'utilisateur.")
    options = models.TextField(blank=True, null=True, help_text="Pour les listes, séparez les options par un point-virgule (;).")
    est_obligatoire = models.BooleanField(default=False)
    ordre = models.PositiveIntegerField(default=1)
    depend_de = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True, related_name='dependances')
    condition_affichage = models.CharField(max_length=100, blank=True, null=True, help_text="Condition à remplir sur le champ parent. Ex: 'OUI', '> 5', 'CONFORME'")
    permettre_photo = models.BooleanField(default=False, help_text="Autoriser l'ajout d'une ou plusieurs photos à cette réponse.")
    permettre_audio = models.BooleanField(default=False, help_text="Autoriser l'enregistrement d'un commentaire audio.")
    permettre_video = models.BooleanField(default=False, help_text="Autoriser l'enregistrement d'une vidéo.")

    class Meta:
        ordering = ['ordre']
        
    def __str__(self):
        return self.label

# ==============================================================================
# AXE 4 : GESTION DES WORKFLOWS & STATUTS DYNAMIQUES
# ==============================================================================

class StatutWorkflow(models.Model):
    nom = models.CharField(max_length=50, unique=True)
    description = models.CharField(max_length=255, blank=True)
    couleur_html = models.CharField(max_length=7, default='#808080', help_text="Code couleur Hex. Ex: #FF5733")
    est_statut_final = models.BooleanField(default=False, help_text="Cocher si c'est un statut de clôture (Terminé, Annulé).")
    
    def __str__(self):
        return self.nom

# ==============================================================================
# AXE 5 : GESTION DE LA PLANIFICATION & ORDRES DE TRAVAIL (OT)
# ==============================================================================

class PlanMaintenancePreventive(models.Model):
    intervention = models.ForeignKey(Intervention, on_delete=models.PROTECT)
    asset_concerne = models.ForeignKey(Asset, on_delete=models.CASCADE, related_name="plans_maintenance")
    frequence_jours = models.PositiveIntegerField(null=True, blank=True)
    date_prochaine_echeance = models.DateField(null=True, blank=True)
    actif = models.BooleanField(default=True)
    
    def __str__(self):
        return f"Plan préventif pour {self.asset_concerne.nom}"

class OrdreDeTravail(models.Model):
    TYPE_OT_CHOIX = [
        ('PREVENTIVE', 'Préventive'),
        ('CORRECTIVE', 'Corrective'),
        ('PREDICTIVE', 'Prédictive'),
        ('INSPECTION', 'Inspection'),
        ('AUDIT', 'Audit'),
        ('AUTRE', 'Autre')
    ]
    
    titre = models.CharField(max_length=255)
    type_OT = models.CharField(max_length=20, choices=TYPE_OT_CHOIX, default='AUTRE')
    intervention = models.ForeignKey(Intervention, on_delete=models.PROTECT)
    cree_par = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='ordres_de_travail_crees', help_text="L'utilisateur qui a initialement créé l'ordre de travail.")
    assigne_a_technicien = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='taches_assignees')
    assigne_a_equipe = models.ForeignKey(Equipe, on_delete=models.SET_NULL, null=True, blank=True)
    asset = models.ForeignKey(Asset, on_delete=models.CASCADE)
    statut = models.ForeignKey(StatutWorkflow, on_delete=models.SET_NULL, null=True, blank=True)
    priorite = models.PositiveIntegerField(choices=[(1, 'Basse'), (2, 'Normale'), (3, 'Haute'), (4, 'Urgente')], default=2)
    date_creation = models.DateTimeField(default=timezone.now)
    date_prevue_debut = models.DateTimeField()
    date_debut_reel = models.DateTimeField(null=True, blank=True, help_text="Date et heure réelles du début de l'intervention.")
    date_fin_reelle = models.DateTimeField(null=True, blank=True, help_text="Date et heure réelles de la fin de l'intervention.")
    cout_main_oeuvre_reel = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    cout_pieces_reel = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)

    def __str__(self):
        return f"OT-{self.id}: {self.titre}"

    def save(self, *args, **kwargs):
        """Logique automatique lors de la sauvegarde"""
        # Si aucun statut n'est défini, on prend le premier statut non-final
        if not self.statut:
            self.statut = StatutWorkflow.objects.filter(est_statut_final=False).first()
        super().save(*args, **kwargs)

# ==============================================================================
# AXE 6 : GESTION DE L'EXÉCUTION & RAPPORTS
# ==============================================================================

class RapportExecution(models.Model):
    STATUT_RAPPORT_CHOIX = [
        ('BROUILLON', 'Brouillon'),
        ('EN_COURS', 'En cours'),
        ('FINALISE', 'Finalisé'),
        ('ARCHIVE', 'Archivé'),
    ]
    
    ordre_de_travail = models.OneToOneField(OrdreDeTravail, on_delete=models.CASCADE, related_name="rapport")
    statut_rapport = models.CharField(max_length=20, choices=STATUT_RAPPORT_CHOIX, default='BROUILLON')
    date_creation = models.DateTimeField(default=timezone.now)
    date_derniere_maj = models.DateTimeField(auto_now=True)
    date_execution_debut = models.DateTimeField(null=True, blank=True)
    date_execution_fin = models.DateTimeField(null=True, blank=True)
    cree_par = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='rapports_crees')
    commentaire_global = models.TextField(blank=True, null=True, help_text="Commentaire général sur l'intervention.")
    
    def __str__(self):
        return f"Rapport OT-{self.ordre_de_travail.id}"

class MouvementStock(models.Model):
    TYPE_MOUVEMENT_CHOIX = [
        ('ENTREE', 'Entrée'),
        ('SORTIE', 'Sortie'),
        ('TRANSFERT', 'Transfert'),
        ('AJUSTEMENT', 'Ajustement'),
    ]
    
    piece_detachee = models.ForeignKey(PieceDetachee, on_delete=models.CASCADE, related_name='mouvements')
    type_mouvement = models.CharField(max_length=20, choices=TYPE_MOUVEMENT_CHOIX)
    quantite = models.IntegerField()
    ordre_de_travail = models.ForeignKey(OrdreDeTravail, on_delete=models.SET_NULL, null=True, blank=True, related_name='mouvements_stock')
    date_mouvement = models.DateTimeField(default=timezone.now)
    effectue_par = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    commentaire = models.TextField(blank=True, null=True)
    
    def __str__(self):
        return f"{self.type_mouvement} - {self.piece_detachee.nom} : {self.quantite}"

class Reponse(models.Model):
    rapport_execution = models.ForeignKey(RapportExecution, on_delete=models.CASCADE, related_name='reponses')
    point_de_controle = models.ForeignKey(PointDeControle, on_delete=models.CASCADE)
    valeur = models.TextField(blank=True, null=True)
    date_reponse = models.DateTimeField(default=timezone.now)
    saisi_par = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    
    class Meta:
        unique_together = ('rapport_execution', 'point_de_controle')
    
    def __str__(self):
        return f"Réponse à '{self.point_de_controle.label}': {self.valeur}"

class FichierMedia(models.Model):
    TYPE_FICHIER_CHOIX = [
        ('PHOTO', 'Photo'),
        ('AUDIO', 'Audio'),
        ('VIDEO', 'Vidéo'),
        ('DOCUMENT', 'Document'),
    ]
    
    reponse = models.ForeignKey(Reponse, on_delete=models.CASCADE, related_name='fichiers_media')
    type_fichier = models.CharField(max_length=20, choices=TYPE_FICHIER_CHOIX)
    fichier = models.FileField(upload_to='media_rapports/')
    nom_original = models.CharField(max_length=255)
    taille_octets = models.PositiveBigIntegerField()
    date_upload = models.DateTimeField(default=timezone.now)
    
    def __str__(self):
        return f"{self.type_fichier} - {self.nom_original}"

# ==============================================================================
# AXE 7 : ACTIONS CORRECTIVES & COMMENTAIRES
# ==============================================================================

class ActionCorrective(models.Model):
    STATUT_ACTION_CHOIX = [
        ('A_PLANIFIER', 'À planifier'),
        ('PLANIFIEE', 'Planifiée'),
        ('EN_COURS', 'En cours'),
        ('TERMINEE', 'Terminée'),
        ('ANNULEE', 'Annulée'),
    ]
    
    rapport_execution = models.ForeignKey(RapportExecution, on_delete=models.CASCADE, related_name='actions_correctives')
    titre = models.CharField(max_length=255)
    description = models.TextField()
    priorite = models.PositiveIntegerField(choices=[(1, 'Basse'), (2, 'Normale'), (3, 'Haute'), (4, 'Urgente')], default=2)
    statut = models.CharField(max_length=20, choices=STATUT_ACTION_CHOIX, default='A_PLANIFIER')
    assigne_a = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True)
    date_echeance = models.DateField(null=True, blank=True)
    date_creation = models.DateTimeField(default=timezone.now)
    cree_par = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='actions_correctives_creees')
    
    def __str__(self):
        return self.titre

class CommentaireOT(models.Model):
    ordre_de_travail = models.ForeignKey(OrdreDeTravail, on_delete=models.CASCADE, related_name='commentaires')
    auteur = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    contenu = models.TextField()
    date_creation = models.DateTimeField(default=timezone.now)
    
    class Meta:
        ordering = ['-date_creation']
    
    def __str__(self):
        return f"Commentaire de {self.auteur.username} - {self.date_creation.strftime('%d/%m/%Y %H:%M')}"

# ==============================================================================
# AXE 8 : NOTIFICATIONS & PARAMÈTRES SYSTÈME
# ==============================================================================

class Notification(models.Model):
    TYPE_NOTIFICATION_CHOIX = [
        ('INFO', 'Information'),
        ('ALERTE', 'Alerte'),
        ('ERREUR', 'Erreur'),
        ('SUCCES', 'Succès'),
    ]
    
    utilisateur = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='notifications')
    titre = models.CharField(max_length=255)
    message = models.TextField()
    type_notification = models.CharField(max_length=20, choices=TYPE_NOTIFICATION_CHOIX, default='INFO')
    lue = models.BooleanField(default=False)
    date_creation = models.DateTimeField(default=timezone.now)
    
    class Meta:
        ordering = ['-date_creation']
    
    def __str__(self):
        return f"{self.titre} - {self.utilisateur.username}"

class ParametreGlobal(models.Model):
    cle = models.CharField(max_length=100, unique=True)
    valeur = models.TextField()
    description = models.TextField(blank=True, null=True)
    
    def __str__(self):
        return f"{self.cle}: {self.valeur}"

class ParametreUtilisateur(models.Model):
    utilisateur = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='parametres')
    cle = models.CharField(max_length=100)
    valeur = models.TextField()
    
    class Meta:
        unique_together = ('utilisateur', 'cle')
    
    def __str__(self):
        return f"{self.utilisateur.username} - {self.cle}: {self.valeur}"