# Fichier : core/views.py - Version complète avec workflow Manager/Technicien

# ==============================================================================
# IMPORTATIONS
# ==============================================================================

import json
import os
from decimal import Decimal
from datetime import datetime, timedelta
from io import BytesIO

from django.contrib import messages
from django.contrib.auth import login, logout, authenticate, update_session_auth_hash
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User
from django.core.exceptions import PermissionDenied
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db import models
from django.db.models import (Count, Sum, Avg, F, Q, Case, When, IntegerField, 
                             Exists, OuterRef, BooleanField, CharField, Max)
from django.http import JsonResponse, HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.template.loader import get_template
from django.urls import reverse
from django.utils import timezone
from django.conf import settings

# Importations des modèles
from .models import *

# Importations des formulaires
from .forms import *

# ==============================================================================
# FONCTIONS DE CONTRÔLE D'ACCÈS
# ==============================================================================

def is_manager_or_admin(user):
    """Vérifie si l'utilisateur est Manager ou Admin"""
    if not user.is_authenticated:
        return False
    try:
        return user.profil.role in ['MANAGER', 'ADMIN']
    except:
        return False

def is_technicien(user):
    """Vérifie si l'utilisateur est Technicien"""
    if not user.is_authenticated:
        return False
    try:
        return user.profil.role == 'TECHNICIEN'
    except:
        return False

def get_user_role(user):
    """Récupère le rôle de l'utilisateur"""
    try:
        return user.profil.role if hasattr(user, 'profil') else 'OPERATEUR'
    except:
        return 'OPERATEUR'

# ==============================================================================
# VUES POUR L'AUTHENTIFICATION
# ==============================================================================

def inscription_view(request):
    """Gère l'inscription de nouveaux utilisateurs."""
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Créer automatiquement un profil utilisateur
            ProfilUtilisateur.objects.create(user=user, role='OPERATEUR')
            username = form.cleaned_data.get('username')
            messages.success(request, f'Compte créé pour {username}!')
            return redirect('connexion')
    else:
        form = UserCreationForm()
    return render(request, 'core/auth/inscription.html', {'form': form})

def connexion_view(request):
    """Gère la connexion des utilisateurs."""
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.info(request, f'Vous êtes maintenant connecté en tant que {username}.')
                return redirect('dashboard')
            else:
                messages.error(request, 'Nom d\'utilisateur ou mot de passe invalide.')
        else:
            messages.error(request, 'Nom d\'utilisateur ou mot de passe invalide.')
    else:
        form = AuthenticationForm()
    return render(request, 'core/auth/connexion.html', {'form': form})

def deconnexion_view(request):
    """Gère la déconnexion des utilisateurs."""
    logout(request)
    messages.info(request, 'Vous avez été déconnecté avec succès.')
    return redirect('connexion')

# ==============================================================================
# TABLEAU DE BORD ADAPTÉ PAR RÔLE
# ==============================================================================

@login_required
def dashboard(request):
    """Tableau de bord adapté selon le rôle utilisateur"""
    user_role = get_user_role(request.user)
    
    # Statistiques de base
    stats = {
        'ordres_actifs': OrdreDeTravail.objects.exclude(statut__est_statut_final=True).count(),
        'interventions_validees': Intervention.objects.filter(statut='VALIDATED').count(),
        'assets_total': Asset.objects.count(),
        'assets_en_panne': Asset.objects.filter(statut='EN_PANNE').count(),
    }
    
    # Ordres spécifiques selon le rôle
    if user_role == 'TECHNICIEN':
        # Pour les techniciens : leurs ordres assignés uniquement
        mes_ordres = OrdreDeTravail.objects.filter(
            Q(assigne_a_technicien=request.user) | 
            Q(assigne_a_equipe__membres=request.user)
        ).exclude(statut__est_statut_final=True).select_related(
            'intervention', 'asset', 'statut'
        )[:5]
        
        ordres_recents = mes_ordres
        
    elif user_role in ['MANAGER', 'ADMIN']:
        # Pour les managers : vue globale
        mes_ordres = OrdreDeTravail.objects.filter(
            Q(assigne_a_technicien=request.user) | 
            Q(assigne_a_equipe__membres=request.user) |
            Q(cree_par=request.user)
        ).exclude(statut__est_statut_final=True).select_related(
            'intervention', 'asset', 'statut'
        )[:5]
        
        ordres_recents = OrdreDeTravail.objects.select_related(
            'intervention', 'asset', 'statut', 'cree_par'
        ).order_by('-date_creation')[:10]
        
    else:
        # Pour les autres rôles
        mes_ordres = OrdreDeTravail.objects.filter(
            Q(cree_par=request.user) |
            Q(assigne_a_technicien=request.user) | 
            Q(assigne_a_equipe__membres=request.user)
        ).exclude(statut__est_statut_final=True).select_related(
            'intervention', 'asset', 'statut'
        )[:5]
        
        ordres_recents = mes_ordres
    
    # Assets critiques en panne
    assets_critiques = Asset.objects.filter(
        statut='EN_PANNE',
        criticite__gte=3
    ).order_by('-criticite')[:5]
    
    context = {
        'stats': stats,
        'ordres_recents': ordres_recents,
        'assets_critiques': assets_critiques,
        'mes_ordres': mes_ordres,
        'user_role': user_role,
    }
    
    return render(request, 'core/dashboard.html', context)

# ==============================================================================
# GESTION DES INTERVENTIONS (Manager/Admin uniquement)
# ==============================================================================

@login_required
@user_passes_test(is_manager_or_admin)
def liste_interventions(request):
    """Liste les interventions - Accès Manager/Admin uniquement"""
    query = request.GET.get('search', '')
    
    interventions_list = Intervention.objects.all()
    
    if query:
        interventions_list = interventions_list.filter(
            Q(nom__icontains=query) | 
            Q(description__icontains=query)
        )
    
    interventions_list = interventions_list.order_by('-id')
    
    # Pagination
    paginator = Paginator(interventions_list, 6)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'interventions_page': page_obj,
        'search_query': query,
    }
    return render(request, 'core/intervention/liste_interventions.html', context)

@login_required
@user_passes_test(is_manager_or_admin)
def creer_intervention(request):
    """Crée une nouvelle intervention - Accès Manager/Admin uniquement"""
    if request.method == 'POST':
        form = InterventionForm(request.POST)
        if form.is_valid():
            intervention = form.save()
            messages.success(request, f'Intervention "{intervention.nom}" créée avec succès!')
            return redirect('intervention_builder', pk=intervention.pk)
    else:
        form = InterventionForm()
    
    return render(request, 'core/intervention/creer_intervention.html', {'form': form})

@login_required
@user_passes_test(is_manager_or_admin)
def intervention_builder(request, pk):
    """Constructeur d'intervention complet - Accès Manager/Admin uniquement"""
    intervention = get_object_or_404(Intervention, pk=pk)
    
    # Traitement des actions POST
    if request.method == 'POST':
        action = request.POST.get('action')
        
        if action == 'update_intervention':
            form = InterventionForm(request.POST, instance=intervention)
            if form.is_valid():
                form.save()
                messages.success(request, 'Intervention mise à jour avec succès!')
        
        elif action == 'add_operation':
            nom_operation = request.POST.get('nom')
            if nom_operation:
                # Calculer l'ordre automatiquement
                max_ordre = intervention.operations.aggregate(
                    max_ordre=models.Max('ordre')
                )['max_ordre'] or 0
                
                operation = Operation.objects.create(
                    intervention=intervention,
                    nom=nom_operation,
                    ordre=max_ordre + 1
                )
                messages.success(request, f'Opération "{operation.nom}" ajoutée!')
        
        elif action == 'add_point':
            operation_id = request.POST.get('operation_id')
            operation = get_object_or_404(Operation, pk=operation_id, intervention=intervention)
            
            # Calculer l'ordre automatiquement
            max_ordre = operation.points_de_controle.aggregate(
                max_ordre=models.Max('ordre')
            )['max_ordre'] or 0
            
            point = PointDeControle.objects.create(
                operation=operation,
                label=request.POST.get('label'),
                type_champ=request.POST.get('type_champ'),
                aide=request.POST.get('aide', ''),
                options=request.POST.get('options', ''),
                est_obligatoire=request.POST.get('est_obligatoire') == 'on',
                permettre_photo=request.POST.get('permettre_photo') == 'on',
                permettre_audio=request.POST.get('permettre_audio') == 'on',
                permettre_video=request.POST.get('permettre_video') == 'on',
                ordre=max_ordre + 1
            )
            messages.success(request, f'Point de contrôle "{point.label}" ajouté!')
        
        elif action == 'delete_operation':
            operation_id = request.POST.get('operation_id')
            operation = get_object_or_404(Operation, pk=operation_id, intervention=intervention)
            operation_name = operation.nom
            operation.delete()
            messages.success(request, f'Opération "{operation_name}" supprimée!')
        
        elif action == 'delete_point':
            point_id = request.POST.get('point_id')
            point = get_object_or_404(PointDeControle, pk=point_id)
            point_name = point.label
            point.delete()
            messages.success(request, f'Point de contrôle "{point_name}" supprimé!')
        
        elif action == 'validate_intervention':
            intervention.statut = 'VALIDATED'
            intervention.save()
            messages.success(request, 'Intervention validée avec succès!')
        
        return redirect('intervention_builder', pk=pk)
    
    # Préparer le contexte
    operations = intervention.operations.all().order_by('ordre')
    intervention_form = InterventionForm(instance=intervention)
    
    context = {
        'intervention': intervention,
        'operations': operations,
        'intervention_form': intervention_form,
    }
    return render(request, 'core/intervention/intervention_builder.html', context)

@login_required
@user_passes_test(is_manager_or_admin)
def supprimer_intervention(request, pk):
    """Supprime une intervention - Accès Manager/Admin uniquement"""
    intervention = get_object_or_404(Intervention, pk=pk)
    
    # Vérifier qu'aucun OT n'utilise cette intervention
    ordres_utilisant = OrdreDeTravail.objects.filter(intervention=intervention).count()
    if ordres_utilisant > 0:
        messages.error(request, f'Impossible de supprimer cette intervention car {ordres_utilisant} ordre(s) de travail l\'utilise(nt).')
        return redirect('intervention_builder', pk=pk)
    
    if request.method == 'POST':
        intervention_name = intervention.nom
        intervention.delete()
        messages.success(request, f'Intervention "{intervention_name}" supprimée!')
        return redirect('liste_interventions')
    
    return render(request, 'core/intervention/supprimer_intervention.html', {
        'intervention': intervention,
        'ordres_utilisant': ordres_utilisant
    })

# Alias pour la compatibilité
intervention_detail = intervention_builder


@login_required
@user_passes_test(is_manager_or_admin)
def preview_intervention(request, pk):
    """Aperçu de l'intervention comme la verrait un technicien"""
    intervention = get_object_or_404(Intervention, pk=pk)
    operations = intervention.operations.all().order_by('ordre')
    
    # Simuler des réponses d'exemple pour la démonstration
    reponses_demo = {}
    for operation in operations:
        for point in operation.points_de_controle.all():
            if point.type_champ == 'BOOLEAN':
                reponses_demo[point.id] = 'OUI' if point.id % 2 == 0 else 'NON'
            elif point.type_champ == 'SELECT' and point.options:
                options = point.options.split(';')
                reponses_demo[point.id] = options[0] if options else ''
            elif point.type_champ == 'NUMBER':
                reponses_demo[point.id] = '25.5'
            elif point.type_champ in ['TEXT', 'TEXTAREA']:
                reponses_demo[point.id] = 'Exemple de réponse de démonstration'
            elif point.type_champ == 'DATE':
                reponses_demo[point.id] = '2024-12-31'
            elif point.type_champ == 'TIME':
                reponses_demo[point.id] = '14:30'
            elif point.type_champ == 'DATETIME':
                reponses_demo[point.id] = '2024-12-31T14:30'
    
    context = {
        'intervention': intervention,
        'operations': operations,
        'reponses_demo': reponses_demo,
        'is_preview': True,
    }
    
    return render(request, 'core/intervention/preview_intervention.html', context)

# ==============================================================================
# GESTION DES ORDRES DE TRAVAIL
# ==============================================================================

@login_required
def liste_ordres_travail(request):
    """Liste tous les ordres de travail avec filtres selon le rôle"""
    ordres = OrdreDeTravail.objects.select_related(
        'intervention', 'asset', 'statut', 'cree_par', 'assigne_a_technicien'
    )
    
    # Filtrer selon le rôle
    user_role = get_user_role(request.user)
    
    if user_role == 'TECHNICIEN':
        # Les techniciens ne voient que leurs ordres assignés
        ordres = ordres.filter(
            Q(assigne_a_technicien=request.user) | 
            Q(assigne_a_equipe__membres=request.user)
        )
    elif user_role in ['MANAGER', 'ADMIN']:
        # Managers et admins voient tout
        pass
    else:
        # Autres rôles voient leurs ordres créés/assignés
        ordres = ordres.filter(
            Q(cree_par=request.user) |
            Q(assigne_a_technicien=request.user) | 
            Q(assigne_a_equipe__membres=request.user)
        )
    
    ordres = ordres.order_by('-date_creation')
    
    # Filtres
    statut_filter = request.GET.get('statut')
    priorite_filter = request.GET.get('priorite')
    type_filter = request.GET.get('type_OT')
    search = request.GET.get('search')
    
    if statut_filter:
        ordres = ordres.filter(statut__nom=statut_filter)
    
    if priorite_filter:
        ordres = ordres.filter(priorite=priorite_filter)
    
    if type_filter:
        ordres = ordres.filter(type_OT=type_filter)
    
    if search:
        ordres = ordres.filter(
            Q(titre__icontains=search) |
            Q(asset__nom__icontains=search) |
            Q(intervention__nom__icontains=search)
        )
    
    # Pagination
    paginator = Paginator(ordres, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    # Données pour les filtres
    statuts = StatutWorkflow.objects.all()
    priorites = [(1, 'Basse'), (2, 'Normale'), (3, 'Haute'), (4, 'Urgente')]
    types_ot = OrdreDeTravail.TYPE_OT_CHOIX
    
    context = {
        'ordres_page': page_obj,
        'statuts': statuts,
        'priorites': priorites,
        'types_ot': types_ot,
        'current_filters': {
            'statut': statut_filter,
            'priorite': priorite_filter,
            'type_OT': type_filter,
            'search': search,
        },
        'user_role': user_role
    }
    
    return render(request, 'core/ot/liste_ordres_travail.html', context)

@login_required
@user_passes_test(is_manager_or_admin)
def creer_ordre_travail(request):
    """Crée un nouvel ordre de travail - Accès Manager/Admin uniquement"""
    if request.method == 'POST':
        form = OrdreDeTravailForm(request.POST)
        if form.is_valid():
            ordre = form.save(commit=False)
            ordre.cree_par = request.user
            ordre.save()
            
            # Créer automatiquement un rapport d'exécution
            RapportExecution.objects.create(
                ordre_de_travail=ordre,
                cree_par=request.user
            )
            
            messages.success(request, f'Ordre de travail "{ordre.titre}" créé avec succès!')
            return redirect('detail_ordre_travail', pk=ordre.pk)
    else:
        form = OrdreDeTravailForm()
    
    return render(request, 'core/ot/creer_ordre_travail.html', {'form': form})


@login_required
def detail_ordre_travail(request, pk):
    """Affiche les détails d'un ordre de travail"""
    ordre = get_object_or_404(OrdreDeTravail, pk=pk)
    
    # Vérifier les permissions d'accès
    user_role = get_user_role(request.user)
    
    can_view = (
        user_role in ['MANAGER', 'ADMIN'] or
        ordre.cree_par == request.user or
        ordre.assigne_a_technicien == request.user or
        (ordre.assigne_a_equipe and request.user in ordre.assigne_a_equipe.membres.all())
    )
    
    if not can_view:
        messages.error(request, "Vous n'avez pas accès à cet ordre de travail.")
        return redirect('liste_ordres_travail')
    
    # Récupérer ou créer le rapport d'exécution
    rapport, created = RapportExecution.objects.get_or_create(
        ordre_de_travail=ordre,
        defaults={'cree_par': request.user}
    )

    # 🔧 Extraire les IDs des points de contrôle déjà remplis
    reponses_ids = set()
    if rapport:
        reponses_ids = set(
            rapport.reponses.values_list('point_de_controle_id', flat=True)
        )
    
    # Traitement des commentaires
    if request.method == 'POST' and request.POST.get('action') == 'add_comment':
        contenu = request.POST.get('contenu')
        if contenu:
            CommentaireOT.objects.create(
                ordre_de_travail=ordre,
                auteur=request.user,
                contenu=contenu
            )
            messages.success(request, 'Commentaire ajouté!')
            return redirect('detail_ordre_travail', pk=pk)
    
    # Commentaires
    commentaires = ordre.commentaires.all().order_by('-date_creation')
    
    # Actions correctives
    actions_correctives = rapport.actions_correctives.all().order_by('-date_creation')
    
    # Vérifier si l'utilisateur peut commencer l'intervention
    peut_executer = (
        ordre.assigne_a_technicien == request.user or
        (ordre.assigne_a_equipe and request.user in ordre.assigne_a_equipe.membres.all()) or
        user_role in ['MANAGER', 'ADMIN']
    )
    
    context = {
        'ordre_de_travail': ordre,
        'rapport': rapport,
        'commentaires': commentaires,
        'actions_correctives': actions_correctives,
        'peut_executer': peut_executer,
        'user_role': user_role,
        'reponses_ids': reponses_ids,  # 👈 Ajout clé
    }
    return render(request, 'core/ot/detail_ordre_travail.html', context)

@login_required
@user_passes_test(is_manager_or_admin)
def modifier_ordre_travail(request, pk):
    """Modifie un ordre de travail existant - Accès Manager/Admin uniquement"""
    ordre = get_object_or_404(OrdreDeTravail, pk=pk)
    
    if request.method == 'POST':
        form = OrdreDeTravailEditForm(request.POST, instance=ordre)
        if form.is_valid():
            ordre_modifie = form.save()
            messages.success(request, f'Ordre de travail "{ordre.titre}" mis à jour avec succès!')
            return redirect('detail_ordre_travail', pk=ordre.pk)
    else:
        form = OrdreDeTravailEditForm(instance=ordre)
    
    context = {
        'form': form,
        'ordre_de_travail': ordre,
    }
    return render(request, 'core/ot/modifier_ordre_travail.html', context)

@login_required
@user_passes_test(is_manager_or_admin)
def supprimer_ordre_travail(request, pk):
    """Supprime un ordre de travail - Accès Manager/Admin uniquement"""
    ordre = get_object_or_404(OrdreDeTravail, pk=pk)
    
    if request.method == 'POST':
        ordre_titre = ordre.titre
        ordre.delete()
        messages.success(request, f'Ordre de travail "{ordre_titre}" supprimé!')
        return redirect('liste_ordres_travail')
    
    return render(request, 'core/ot/supprimer_ordre_travail.html', {
        'ordre_de_travail': ordre
    })

# ==============================================================================
# EXÉCUTION DES INTERVENTIONS
# ==============================================================================

@login_required
def commencer_intervention(request, pk):
    """Démarre l'exécution d'un ordre de travail"""
    ordre = get_object_or_404(OrdreDeTravail, pk=pk)
    
    # Vérifier que l'utilisateur peut commencer cette intervention
    user_role = get_user_role(request.user)
    
    peut_commencer = (
        ordre.assigne_a_technicien == request.user or
        (ordre.assigne_a_equipe and request.user in ordre.assigne_a_equipe.membres.all()) or
        user_role in ['MANAGER', 'ADMIN']
    )
    
    if not peut_commencer:
        messages.error(request, "Vous n'êtes pas autorisé à commencer cette intervention.")
        return redirect('detail_ordre_travail', pk=pk)
    
    # Récupérer ou créer le rapport
    rapport, created = RapportExecution.objects.get_or_create(
        ordre_de_travail=ordre,
        defaults={'cree_par': request.user}
    )
    
    # Marquer le début de l'intervention
    if not rapport.date_execution_debut:
        rapport.date_execution_debut = timezone.now()
        rapport.statut_rapport = 'EN_COURS'
        rapport.save()
        
        # Mettre à jour l'ordre de travail
        ordre.date_debut_reel = timezone.now()
        # Changer le statut vers "En cours"
        statut_en_cours = StatutWorkflow.objects.filter(nom='EN_COURS').first()
        if statut_en_cours:
            ordre.statut = statut_en_cours
        ordre.save()
        
        messages.success(request, "Intervention démarrée!")
    
    return redirect('executer_intervention', pk=pk)

@login_required
def executer_intervention(request, pk):
    """Interface d'exécution de l'intervention avec formulaire dynamique"""
    ordre = get_object_or_404(OrdreDeTravail, pk=pk)
    
    # Vérifier les permissions
    user_role = get_user_role(request.user)
    
    peut_executer = (
        ordre.assigne_a_technicien == request.user or
        (ordre.assigne_a_equipe and request.user in ordre.assigne_a_equipe.membres.all()) or
        user_role in ['MANAGER', 'ADMIN']
    )
    
    if not peut_executer:
        messages.error(request, "Vous n'êtes pas autorisé à exécuter cette intervention.")
        return redirect('detail_ordre_travail', pk=pk)
    
    rapport = get_object_or_404(RapportExecution, ordre_de_travail=ordre)
    
    # Récupérer toutes les opérations et points de contrôle
    operations = ordre.intervention.operations.all().order_by('ordre')
    
    # Traitement des réponses soumises
    if request.method == 'POST':
        action = request.POST.get('action')
        
        if action == 'sauvegarder_reponses':
            # Sauvegarder toutes les réponses
            for key, value in request.POST.items():
                if key.startswith('point_'):
                    point_id = key.replace('point_', '')
                    try:
                        point = PointDeControle.objects.get(id=point_id)
                        reponse, created = Reponse.objects.get_or_create(
                            rapport_execution=rapport,
                            point_de_controle=point,
                            defaults={'saisi_par': request.user}
                        )
                        reponse.valeur = value
                        reponse.saisi_par = request.user
                        reponse.date_reponse = timezone.now()
                        reponse.save()
                    except PointDeControle.DoesNotExist:
                        continue
            
            messages.success(request, "Réponses sauvegardées!")
        
        elif action == 'finaliser_intervention':
            # Vérifier que tous les points obligatoires sont remplis
            points_obligatoires = []
            for operation in operations:
                for point in operation.points_de_controle.filter(est_obligatoire=True):
                    points_obligatoires.append(point)
            
            reponses_manquantes = []
            for point in points_obligatoires:
                if not rapport.reponses.filter(point_de_controle=point).exists():
                    reponses_manquantes.append(point.label)
            
            if reponses_manquantes:
                messages.error(request, f"Points obligatoires manquants: {', '.join(reponses_manquantes)}")
            else:
                # Finaliser l'intervention
                rapport.statut_rapport = 'FINALISE'
                rapport.date_execution_fin = timezone.now()
                rapport.save()
                
                # Mettre à jour l'ordre de travail
                ordre.date_fin_reelle = timezone.now()
                # Changer le statut vers "Terminé"
                statut_termine = StatutWorkflow.objects.filter(nom='TERMINE').first()
                if statut_termine:
                    ordre.statut = statut_termine
                ordre.save()
                
                messages.success(request, "Intervention finalisée avec succès!")
                return redirect('detail_ordre_travail', pk=pk)
    
    # Récupérer les réponses existantes
    reponses_existantes = {}
    for reponse in rapport.reponses.all():
        reponses_existantes[reponse.point_de_controle.id] = reponse.valeur
    
    context = {
        'ordre_de_travail': ordre,
        'rapport': rapport,
        'operations': operations,
        'reponses_existantes': reponses_existantes,
        'user_role': user_role,
    }
    
    return render(request, 'core/execution/executer_intervention.html', context)

# ==============================================================================
# GESTION DES PROFILS UTILISATEURS
# ==============================================================================

@login_required
def profil_utilisateur(request):
    """Affiche et permet de modifier le profil de l'utilisateur connecté."""
    profil, created = ProfilUtilisateur.objects.get_or_create(
        user=request.user,
        defaults={'role': 'OPERATEUR'}
    )
    
    if request.method == 'POST':
        user_form = UserUpdateForm(request.POST, instance=request.user)
        profil_form = ProfilUtilisateurUpdateForm(request.POST, instance=profil)
        
        if user_form.is_valid() and profil_form.is_valid():
            user_form.save()
            profil_form.save()
            messages.success(request, 'Votre profil a été mis à jour avec succès!')
            return redirect('profil_utilisateur')
    else:
        user_form = UserUpdateForm(instance=request.user)
        profil_form = ProfilUtilisateurUpdateForm(instance=profil)
    
    context = {
        'user_form': user_form,
        'profil_form': profil_form,
        'profil': profil,
    }
    
    return render(request, 'core/profil/profil_utilisateur.html', context)

@login_required
def changer_mot_de_passe(request):
    """Permet à l'utilisateur de changer son mot de passe."""
    if request.method == 'POST':
        form = CustomPasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)
            messages.success(request, 'Votre mot de passe a été changé avec succès!')
            return redirect('profil_utilisateur')
        else:
            messages.error(request, 'Veuillez corriger les erreurs ci-dessous.')
    else:
        form = CustomPasswordChangeForm(request.user)
    
    return render(request, 'core/profil/changer_mot_de_passe.html', {'form': form})

# ==============================================================================
# APIs AJAX POUR LE CONSTRUCTEUR D'INTERVENTION
# ==============================================================================

@login_required
@user_passes_test(is_manager_or_admin)
def ajax_edit_operation(request, operation_id):
    """Édite une opération via AJAX"""
    if request.method == 'POST':
        operation = get_object_or_404(Operation, pk=operation_id)
        operation.nom = request.POST.get('nom', operation.nom)
        operation.save()
        return JsonResponse({'success': True, 'message': 'Opération mise à jour'})
    return JsonResponse({'success': False})

@login_required
@user_passes_test(is_manager_or_admin)
def ajax_edit_point(request, point_id):
    """Édite un point de contrôle via AJAX"""
    if request.method == 'POST':
        point = get_object_or_404(PointDeControle, pk=point_id)
        
        point.label = request.POST.get('label', point.label)
        point.type_champ = request.POST.get('type_champ', point.type_champ)
        point.aide = request.POST.get('aide', point.aide)
        point.options = request.POST.get('options', point.options)
        point.est_obligatoire = request.POST.get('est_obligatoire') == 'on'
        point.permettre_photo = request.POST.get('permettre_photo') == 'on'
        point.permettre_audio = request.POST.get('permettre_audio') == 'on'
        point.permettre_video = request.POST.get('permettre_video') == 'on'
        
        point.save()
        return JsonResponse({'success': True, 'message': 'Point de contrôle mis à jour'})
    return JsonResponse({'success': False})

@login_required
@user_passes_test(is_manager_or_admin)
def ajax_reorder_operations(request):
    """Réordonne les opérations via AJAX"""
    if request.method == 'POST':
        operation_ids = request.POST.getlist('operation_ids[]')
        for index, operation_id in enumerate(operation_ids, 1):
            Operation.objects.filter(pk=operation_id).update(ordre=index)
        return JsonResponse({'success': True})
    return JsonResponse({'success': False})

# ==============================================================================
# APIs AJAX ET UTILITAIRES
# ==============================================================================

@login_required
def ajax_assets_par_categorie(request):
    """API AJAX pour récupérer les assets par catégorie."""
    categorie_id = request.GET.get('categorie_id')
    
    if categorie_id:
        assets = Asset.objects.filter(
            categorie_id=categorie_id,
            statut__in=['EN_SERVICE', 'EN_MAINTENANCE']
        ).values('id', 'nom', 'reference')
    else:
        assets = Asset.objects.filter(
            statut__in=['EN_SERVICE', 'EN_MAINTENANCE']
        ).values('id', 'nom', 'reference')
    
    return JsonResponse({'assets': list(assets)})

@login_required
def ajax_interventions_validees(request):
    """API AJAX pour récupérer les interventions validées."""
    interventions = Intervention.objects.filter(
        statut='VALIDATED'
    ).values('id', 'nom', 'duree_estimee_heures', 'techniciens_requis')
    
    return JsonResponse({'interventions': list(interventions)})

# ==============================================================================
# RAPPORTS ET EXPORTS
# ==============================================================================

@login_required
def export_rapport_pdf(request, pk):
    """Exporte un rapport d'exécution en PDF."""
    rapport = get_object_or_404(RapportExecution, pk=pk)
    
    # Vérifier les permissions
    user_role = get_user_role(request.user)
    ordre = rapport.ordre_de_travail
    
    can_export = (
        user_role in ['MANAGER', 'ADMIN'] or
        ordre.cree_par == request.user or
        ordre.assigne_a_technicien == request.user or
        (ordre.assigne_a_equipe and request.user in ordre.assigne_a_equipe.membres.all())
    )
    
    if not can_export:
        messages.error(request, "Vous n'avez pas accès à ce rapport.")
        return redirect('liste_ordres_travail')
    
    template_path = 'core/export/rapport_pdf.html'
    context = {
        'rapport': rapport,
        'ordre': rapport.ordre_de_travail,
        'reponses': rapport.reponses.all().order_by(
            'point_de_controle__operation__ordre', 
            'point_de_controle__ordre'
        ),
    }
    
    # Créer un objet HttpResponse avec le bon content-type pour PDF
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="rapport_OT_{rapport.ordre_de_travail.id}.pdf"'
    
    # Générer le PDF
    template = get_template(template_path)
    html = template.render(context)
    
    try:
        from xhtml2pdf import pisa
        result = BytesIO()
        pdf = pisa.pisaDocument(BytesIO(html.encode("ISO-8859-1")), result)
        
        if not pdf.err:
            response.write(result.getvalue())
            return response
    except ImportError:
        messages.error(request, "La génération de PDF n'est pas disponible. Installez xhtml2pdf.")
        return redirect('detail_ordre_travail', pk=rapport.ordre_de_travail.pk)
    
    messages.error(request, "Erreur lors de la génération du PDF.")
    return redirect('detail_ordre_travail', pk=rapport.ordre_de_travail.pk)

# ==============================================================================
# PAGES D'ERREUR ET UTILITAIRES
# ==============================================================================

def handler404(request, exception):
    """Page d'erreur 404 personnalisée."""
    return render(request, 'core/errors/404.html', status=404)

def handler500(request):
    """Page d'erreur 500 personnalisée."""
    return render(request, 'core/errors/500.html', status=500)

# ==============================================================================
# VUES SUPPLÉMENTAIRES POUR LA COMPATIBILITÉ
# ==============================================================================

# Ces vues sont des alias pour assurer la compatibilité avec les URLs existantes
intervention_detail = intervention_builder

# Vue pour preview d'intervention (optionnelle)
@login_required
@user_passes_test(is_manager_or_admin)
def preview_intervention(request, pk):
    """Aperçu de l'intervention comme la verrait un technicien"""
    intervention = get_object_or_404(Intervention, pk=pk)
    operations = intervention.operations.all().order_by('ordre')
    
    context = {
        'intervention': intervention,
        'operations': operations,
        'is_preview': True,
    }
    
    return render(request, 'core/intervention/preview_intervention.html', context)