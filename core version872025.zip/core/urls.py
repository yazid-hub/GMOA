# Fichier : core/urls.py - Version avec workflow Manager/Technicien

from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from . import views

urlpatterns = [
    # ==============================================================================
    # AUTHENTIFICATION
    # ==============================================================================
    path('', views.dashboard, name='dashboard'),
    path('connexion/', views.connexion_view, name='connexion'),
    path('inscription/', views.inscription_view, name='inscription'),
    path('deconnexion/', views.deconnexion_view, name='deconnexion'),
    
    # ==============================================================================
    # TABLEAU DE BORD ADAPTÉ PAR RÔLE
    # ==============================================================================
    path('dashboard/', views.dashboard, name='dashboard'),
    
    # ==============================================================================
    # GESTION DES INTERVENTIONS (Manager/Admin uniquement)
    # ==============================================================================
    path('interventions/', views.liste_interventions, name='liste_interventions'),
    path('interventions/creer/', views.creer_intervention, name='creer_intervention'),
    path('interventions/<int:pk>/', views.intervention_builder, name='intervention_builder'),
    path('interventions/<int:pk>/detail/', views.intervention_builder, name='intervention_detail'),  # Alias
    path('interventions/<int:pk>/supprimer/', views.supprimer_intervention, name='supprimer_intervention'),
    path('interventions/<int:pk>/preview/', views.preview_intervention, name='preview_intervention'),

    # ==============================================================================
    # GESTION DES ORDRES DE TRAVAIL
    # ==============================================================================
    path('ordres-travail/', views.liste_ordres_travail, name='liste_ordres_travail'),
    path('ordres-travail/creer/', views.creer_ordre_travail, name='creer_ordre_travail'),  # Manager uniquement
    path('ordres-travail/<int:pk>/', views.detail_ordre_travail, name='detail_ordre_travail'),
    path('ordres-travail/<int:pk>/modifier/', views.modifier_ordre_travail, name='modifier_ordre_travail'),
    path('ordres-travail/<int:pk>/supprimer/', views.supprimer_ordre_travail, name='supprimer_ordre_travail'),
    
    # ==============================================================================
    # EXÉCUTION DES INTERVENTIONS (Techniciens assignés)
    # ==============================================================================
    path('ordres-travail/<int:pk>/commencer/', views.commencer_intervention, name='commencer_intervention'),
    path('ordres-travail/<int:pk>/executer/', views.executer_intervention, name='executer_intervention'),
    
    # ==============================================================================
    # APIs AJAX POUR LE CONSTRUCTEUR D'INTERVENTION
    # ==============================================================================
    path('ajax/operation/<int:operation_id>/edit/', views.ajax_edit_operation, name='ajax_edit_operation'),
    path('ajax/point/<int:point_id>/edit/', views.ajax_edit_point, name='ajax_edit_point'),
    path('ajax/operations/reorder/', views.ajax_reorder_operations, name='ajax_reorder_operations'),
    
    # ==============================================================================
    # GESTION DES PROFILS UTILISATEURS
    # ==============================================================================
    path('profil/', views.profil_utilisateur, name='profil_utilisateur'),
    path('profil/mot-de-passe/', views.changer_mot_de_passe, name='changer_mot_de_passe'),
    
    # ==============================================================================
    # APIs AJAX ET UTILITAIRES
    # ==============================================================================
    path('ajax/assets-par-categorie/', views.ajax_assets_par_categorie, name='ajax_assets_par_categorie'),
    path('ajax/interventions-validees/', views.ajax_interventions_validees, name='ajax_interventions_validees'),
    
    # ==============================================================================
    # RAPPORTS ET EXPORTS
    # ==============================================================================
    path('rapports/<int:pk>/export-pdf/', views.export_rapport_pdf, name='export_rapport_pdf'),
]

# Servir les fichiers media en développement
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

