# Fichier : core/templatetags/custom_filters.py

from django import template

register = template.Library()

@register.filter
def split(value, delimiter):
    """Divise une chaîne par un délimiteur"""
    if value:
        return value.split(delimiter)
    return []

@register.filter
def get_item(dictionary, key):
    """Récupère un élément d'un dictionnaire par sa clé"""
    if dictionary and key is not None:
        # Convertir la clé en entier si nécessaire
        try:
            if isinstance(key, str):
                key = int(key)
            return dictionary.get(key, '')
        except (ValueError, TypeError):
            return dictionary.get(key, '') if hasattr(dictionary, 'get') else ''
    return ''

@register.filter
def range_filter(value):
    """Crée une liste d'entiers de 0 à value-1"""
    try:
        return range(int(value))
    except (ValueError, TypeError):
        return []

@register.filter
def priority_class(priority):
    """Retourne une classe CSS selon la priorité"""
    classes = {
        1: 'bg-green-100 text-green-800',
        2: 'bg-yellow-100 text-yellow-800', 
        3: 'bg-orange-100 text-orange-800',
        4: 'bg-red-100 text-red-800'
    }
    return classes.get(priority, 'bg-gray-100 text-gray-800')

@register.filter
def priority_text(priority):
    """Retourne le texte de priorité"""
    texts = {
        1: 'Basse',
        2: 'Normale',
        3: 'Haute', 
        4: 'Urgente'
    }
    return texts.get(priority, 'Inconnue')

@register.filter
def mul(value, arg):
    """Multiplie deux valeurs"""
    try:
        return float(value) * float(arg)
    except (ValueError, TypeError):
        return 0

@register.filter
def div(value, arg):
    """Divise deux valeurs"""
    try:
        return float(value) / float(arg)
    except (ValueError, TypeError, ZeroDivisionError):
        return 0

@register.filter
def sub(value, arg):
    """Soustrait deux valeurs"""
    try:
        return float(value) - float(arg)
    except (ValueError, TypeError):
        return 0