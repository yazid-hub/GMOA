// index.js
import { AppRegistry } from 'react-native';
import App from './App';
import { name as appName } from './app.json';

// Configuration console pour le debug
if (__DEV__) {
  console.log('🚀 GMAO Mobile App - Mode Développement');
  
  // Améliorer les logs en développement
  const originalLog = console.log;
  console.log = (...args) => {
    originalLog(`[${new Date().toLocaleTimeString()}]`, ...args);
  };
}

// Gestion des erreurs globales
const originalHandler = ErrorUtils.getGlobalHandler();
const globalHandler = (error, isFatal) => {
  console.error('❌ Erreur globale:', error);
  
  if (__DEV__) {
    // En développement, afficher l'erreur
    originalHandler(error, isFatal);
  } else {
    // En production, logger l'erreur (pourrait envoyer à un service de crash reporting)
    console.error('Production error:', error);
    // TODO: Envoyer à un service comme Crashlytics, Sentry, etc.
  }
};

ErrorUtils.setGlobalHandler(globalHandler);

// Enregistrer l'application
AppRegistry.registerComponent(appName, () => App);

console.log(`✅ Application ${appName} enregistrée`);

// Performance monitoring en développement
if (__DEV__) {
  const startTime = Date.now();
  setTimeout(() => {
    const loadTime = Date.now() - startTime;
    console.log(`⚡ Temps de chargement initial: ${loadTime}ms`);
  }, 0);
}