// src/store/slices/workOrderSlice.ts
import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { WorkOrder, WorkOrderWithDetails } from '../../types/database';
import { WorkOrderOperations } from '../../database/operations';
import { ApiClient } from '../../services/api/ApiClient';

// Types pour l'état des ordres de travail
interface WorkOrderState {
  workOrders: WorkOrderWithDetails[];
  currentWorkOrder: any | null;
  loading: boolean;
  error: string | null;
  filters: {
    status: string[];
    priority: string[];
    dateRange: {
      start: string | null;
      end: string | null;
    };
  };
  searchQuery: string;
  refreshing: boolean;
  lastSync: string | null;
}

// État initial
const initialState: WorkOrderState = {
  workOrders: [],
  currentWorkOrder: null,
  loading: false,
  error: null,
  filters: {
    status: [],
    priority: [],
    dateRange: {
      start: null,
      end: null,
    },
  },
  searchQuery: '',
  refreshing: false,
  lastSync: null,
};

// Thunks asynchrones
export const loadWorkOrders = createAsyncThunk(
  'workOrders/loadWorkOrders',
  async (userId: number, { rejectWithValue }) => {
    try {
      // Charger depuis la base locale
      const workOrders = await WorkOrderOperations.getAssignedWorkOrders(userId);
      return workOrders;
    } catch (error: any) {
      return rejectWithValue(error.message || 'Erreur chargement OT');
    }
  }
);

export const syncWorkOrders = createAsyncThunk(
  'workOrders/syncWorkOrders',
  async (userId: number, { rejectWithValue }) => {
    try {
      // Synchroniser avec le serveur
      const response = await ApiClient.getWorkOrders(userId);
      
      if (response.success) {
        // Sauvegarder en local
        // TODO: Implémenter la sauvegarde en masse
        
        // Recharger depuis la base locale
        const workOrders = await WorkOrderOperations.getAssignedWorkOrders(userId);
        return {
          workOrders,
          syncTime: new Date().toISOString(),
        };
      } else {
        return rejectWithValue(response.error || 'Erreur synchronisation');
      }
    } catch (error: any) {
      return rejectWithValue(error.message || 'Erreur réseau');
    }
  }
);

export const loadWorkOrderDetails = createAsyncThunk(
  'workOrders/loadWorkOrderDetails',
  async (workOrderId: number, { rejectWithValue }) => {
    try {
      const details = await WorkOrderOperations.getWorkOrderDetails(workOrderId);
      if (!details) {
        return rejectWithValue('Ordre de travail non trouvé');
      }
      return details;
    } catch (error: any) {
      return rejectWithValue(error.message || 'Erreur chargement détails');
    }
  }
);

export const updateWorkOrderStatus = createAsyncThunk(
  'workOrders/updateWorkOrderStatus',
  async (
    { workOrderId, status, userId }: { workOrderId: number; status: string; userId?: number },
    { rejectWithValue }
  ) => {
    try {
      await WorkOrderOperations.updateStatus(workOrderId, status, userId);
      
      // Recharger les détails mis à jour
      const updatedDetails = await WorkOrderOperations.getWorkOrderDetails(workOrderId);
      
      return {
        workOrderId,
        status,
        updatedDetails,
      };
    } catch (error: any) {
      return rejectWithValue(error.message || 'Erreur mise à jour statut');
    }
  }
);

export const saveWorkOrder = createAsyncThunk(
  'workOrders/saveWorkOrder',
  async (workOrder: Partial<WorkOrder>, { rejectWithValue }) => {
    try {
      const savedId = await WorkOrderOperations.saveWorkOrder(workOrder);
      
      // Recharger les détails sauvegardés
      const savedWorkOrder = await WorkOrderOperations.getWorkOrderDetails(savedId);
      
      return savedWorkOrder;
    } catch (error: any) {
      return rejectWithValue(error.message || 'Erreur sauvegarde OT');
    }
  }
);

// Slice
const workOrderSlice = createSlice({
  name: 'workOrders',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
    },
    
    setCurrentWorkOrder: (state, action: PayloadAction<any | null>) => {
      state.currentWorkOrder = action.payload;
    },
    
    setFilters: (state, action: PayloadAction<Partial<typeof initialState.filters>>) => {
      state.filters = { ...state.filters, ...action.payload };
    },
    
    setSearchQuery: (state, action: PayloadAction<string>) => {
      state.searchQuery = action.payload;
    },
    
    clearFilters: (state) => {
      state.filters = initialState.filters;
      state.searchQuery = '';
    },
    
    updateWorkOrderInList: (state, action: PayloadAction<{ id: number; updates: Partial<WorkOrder> }>) => {
      const { id, updates } = action.payload;
      const index = state.workOrders.findIndex(wo => wo.id === id);
      if (index !== -1) {
        state.workOrders[index] = { ...state.workOrders[index], ...updates };
      }
      
      // Mettre à jour aussi l'OT courant si c'est le même
      if (state.currentWorkOrder?.id === id) {
        state.currentWorkOrder = { ...state.currentWorkOrder, ...updates };
      }
    },
    
    addWorkOrder: (state, action: PayloadAction<WorkOrderWithDetails>) => {
      state.workOrders.unshift(action.payload);
    },
    
    removeWorkOrder: (state, action: PayloadAction<number>) => {
      state.workOrders = state.workOrders.filter(wo => wo.id !== action.payload);
      if (state.currentWorkOrder?.id === action.payload) {
        state.currentWorkOrder = null;
      }
    },
  },
  
  extraReducers: (builder) => {
    // Chargement des OT
    builder
      .addCase(loadWorkOrders.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(loadWorkOrders.fulfilled, (state, action) => {
        state.loading = false;
        state.workOrders = action.payload;
        state.error = null;
      })
      .addCase(loadWorkOrders.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });

    // Synchronisation des OT
    builder
      .addCase(syncWorkOrders.pending, (state) => {
        state.refreshing = true;
        state.error = null;
      })
      .addCase(syncWorkOrders.fulfilled, (state, action) => {
        state.refreshing = false;
        state.workOrders = action.payload.workOrders;
        state.lastSync = action.payload.syncTime;
        state.error = null;
      })
      .addCase(syncWorkOrders.rejected, (state, action) => {
        state.refreshing = false;
        state.error = action.payload as string;
      });

    // Chargement des détails d'un OT
    builder
      .addCase(loadWorkOrderDetails.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(loadWorkOrderDetails.fulfilled, (state, action) => {
        state.loading = false;
        state.currentWorkOrder = action.payload;
        state.error = null;
      })
      .addCase(loadWorkOrderDetails.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });

    // Mise à jour du statut
    builder
      .addCase(updateWorkOrderStatus.fulfilled, (state, action) => {
        const { workOrderId, updatedDetails } = action.payload;
        
        // Mettre à jour dans la liste
        const index = state.workOrders.findIndex(wo => wo.id === workOrderId);
        if (index !== -1 && updatedDetails) {
          state.workOrders[index] = { ...state.workOrders[index], ...updatedDetails };
        }
        
        // Mettre à jour l'OT courant
        if (state.currentWorkOrder?.id === workOrderId && updatedDetails) {
          state.currentWorkOrder = updatedDetails;
        }
      })
      .addCase(updateWorkOrderStatus.rejected, (state, action) => {
        state.error = action.payload as string;
      });

    // Sauvegarde d'un OT
    builder
      .addCase(saveWorkOrder.fulfilled, (state, action) => {
        const savedWorkOrder = action.payload;
        
        // Ajouter ou mettre à jour dans la liste
        const existingIndex = state.workOrders.findIndex(wo => wo.id === savedWorkOrder.id);
        if (existingIndex !== -1) {
          state.workOrders[existingIndex] = savedWorkOrder;
        } else {
          state.workOrders.unshift(savedWorkOrder);
        }
        
        // Mettre à jour l'OT courant si c'est le même
        if (state.currentWorkOrder?.id === savedWorkOrder.id) {
          state.currentWorkOrder = savedWorkOrder;
        }
      })
      .addCase(saveWorkOrder.rejected, (state, action) => {
        state.error = action.payload as string;
      });
  },
});

// Actions
export const {
  clearError,
  setCurrentWorkOrder,
  setFilters,
  setSearchQuery,
  clearFilters,
  updateWorkOrderInList,
  addWorkOrder,
  removeWorkOrder,
} = workOrderSlice.actions;

// Sélecteurs
export const selectWorkOrders = (state: any) => state.workOrders.workOrders;
export const selectCurrentWorkOrder = (state: any) => state.workOrders.currentWorkOrder;
export const selectWorkOrdersLoading = (state: any) => state.workOrders.loading;
export const selectWorkOrdersError = (state: any) => state.workOrders.error;
export const selectWorkOrdersRefreshing = (state: any) => state.workOrders.refreshing;
export const selectWorkOrderFilters = (state: any) => state.workOrders.filters;
export const selectWorkOrderSearchQuery = (state: any) => state.workOrders.searchQuery;
export const selectLastSync = (state: any) => state.workOrders.lastSync;

// Sélecteurs calculés
export const selectFilteredWorkOrders = (state: any) => {
  const workOrders = selectWorkOrders(state);
  const filters = selectWorkOrderFilters(state);
  const searchQuery = selectWorkOrderSearchQuery(state);
  
  let filtered = workOrders;
  
  // Filtrage par statut
  if (filters.status.length > 0) {
    filtered = filtered.filter((wo: WorkOrderWithDetails) => 
      filters.status.includes(wo.statut)
    );
  }
  
  // Filtrage par priorité
  if (filters.priority.length > 0) {
    filtered = filtered.filter((wo: WorkOrderWithDetails) => 
      filters.priority.includes(wo.priorite)
    );
  }
  
  // Filtrage par recherche
  if (searchQuery.trim()) {
    const query = searchQuery.toLowerCase();
    filtered = filtered.filter((wo: WorkOrderWithDetails) => 
      wo.titre.toLowerCase().includes(query) ||
      wo.numero_ot.toLowerCase().includes(query) ||
      wo.asset_name?.toLowerCase().includes(query) ||
      wo.localisation?.toLowerCase().includes(query)
    );
  }
  
  // Filtrage par date
  if (filters.dateRange.start || filters.dateRange.end) {
    filtered = filtered.filter((wo: WorkOrderWithDetails) => {
      const woDate = new Date(wo.date_planifiee || wo.date_creation);
      const startDate = filters.dateRange.start ? new Date(filters.dateRange.start) : null;
      const endDate = filters.dateRange.end ? new Date(filters.dateRange.end) : null;
      
      if (startDate && woDate < startDate) return false;
      if (endDate && woDate > endDate) return false;
      
      return true;
    });
  }
  
  return filtered;
};

export const selectWorkOrderStats = (state: any) => {
  const workOrders = selectWorkOrders(state);
  
  return {
    total: workOrders.length,
    nouveau: workOrders.filter((wo: WorkOrderWithDetails) => wo.statut === 'NOUVEAU').length,
    en_cours: workOrders.filter((wo: WorkOrderWithDetails) => wo.statut === 'EN_COURS').length,
    termine: workOrders.filter((wo: WorkOrderWithDetails) => wo.statut === 'TERMINE').length,
    urgent: workOrders.filter((wo: WorkOrderWithDetails) => wo.priorite === 'URGENTE').length,
  };
};

export default workOrderSlice.reducer;