// src/store/store.ts
import { configureStore, combineReducers } from '@reduxjs/toolkit';
import { persistStore, persistReducer } from 'redux-persist';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Import des slices
import authSlice from './slices/authSlice';
import workOrderSlice from './slices/workOrderSlice';
import syncSlice from './slices/syncSlice';
import mediaSlice from './slices/mediaSlice';
import assetSlice from './slices/assetSlice';
import settingsSlice from './slices/settingsSlice';
import networkSlice from './slices/networkSlice';

// Configuration de persistance
const persistConfig = {
  key: 'root',
  storage: AsyncStorage,
  whitelist: ['auth', 'settings'], // Seuls ces slices seront persistés
  blacklist: ['sync', 'network'] // Ces slices ne seront pas persistés
};

// Configuration spécifique pour certains slices
const authPersistConfig = {
  key: 'auth',
  storage: AsyncStorage,
  whitelist: ['user', 'token', 'isAuthenticated'] // Seulement ces champs
};

const settingsPersistConfig = {
  key: 'settings',
  storage: AsyncStorage,
};

// Combinaison des reducers
const rootReducer = combineReducers({
  auth: persistReducer(authPersistConfig, authSlice),
  workOrders: workOrderSlice,
  sync: syncSlice,
  media: mediaSlice,
  assets: assetSlice,
  settings: persistReducer(settingsPersistConfig, settingsSlice),
  network: networkSlice,
});

// Reducer principal avec persistance
const persistedReducer = persistReducer(persistConfig, rootReducer);

// Configuration du store
export const store = configureStore({
  reducer: persistedReducer,
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: [
          'persist/PERSIST',
          'persist/REHYDRATE',
          'persist/PAUSE',
          'persist/PURGE',
          'persist/REGISTER',
          'persist/FLUSH',
        ],
      },
    }),
  devTools: __DEV__, // Activer Redux DevTools seulement en dev
});

// Configuration du persistor
export const persistor = persistStore(store);

// Types pour TypeScript
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

// Hooks typés
import { useDispatch, useSelector, TypedUseSelectorHook } from 'react-redux';
export const useAppDispatch = () => useDispatch<AppDispatch>();
export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector;