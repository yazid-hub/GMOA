// src/navigation/AppNavigator.tsx
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { View, Text, StyleSheet, Platform } from 'react-native';
import Icon from 'react-native-vector-icons/Feather';

import { useAppSelector } from '../store/store';
import { selectIsAuthenticated } from '../store/slices/authSlice';
import { theme } from '../styles/theme';

// Screens
import LoginScreen from '../screens/auth/LoginScreen';
import DashboardScreen from '../screens/dashboard/DashboardScreen';
import WorkOrderListScreen from '../screens/workorders/WorkOrderListScreen';
import WorkOrderDetailsScreen from '../screens/workorders/WorkOrderDetailsScreen';
import AssetScanScreen from '../screens/assets/AssetScanScreen';
import ProfileScreen from '../screens/profile/ProfileScreen';
import SettingsScreen from '../screens/settings/SettingsScreen';
import SyncScreen from '../screens/sync/SyncScreen';

// Types pour la navigation
export type AuthStackParamList = {
  Login: undefined;
};

export type MainTabParamList = {
  Dashboard: undefined;
  WorkOrders: undefined;
  Scan: undefined;
  Profile: undefined;
};

export type WorkOrderStackParamList = {
  WorkOrderList: undefined;
  WorkOrderDetails: { workOrderId: number };
  ExecutionForm: { workOrderId: number; operationId?: number };
};

export type RootStackParamList = {
  Auth: undefined;
  Main: undefined;
  Settings: undefined;
  Sync: undefined;
};

// Navigators
const AuthStack = createStackNavigator<AuthStackParamList>();
const MainTab = createBottomTabNavigator<MainTabParamList>();
const WorkOrderStack = createStackNavigator<WorkOrderStackParamList>();
const RootStack = createStackNavigator<RootStackParamList>();

// ============================================================================
// AUTH NAVIGATOR
// ============================================================================

const AuthNavigator: React.FC = () => {
  return (
    <AuthStack.Navigator screenOptions={{ headerShown: false }}>
      <AuthStack.Screen name="Login" component={LoginScreen} />
    </AuthStack.Navigator>
  );
};

// ============================================================================
// WORK ORDER STACK
// ============================================================================

const WorkOrderNavigator: React.FC = () => {
  return (
    <WorkOrderStack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: theme.colors.primary[500],
          elevation: 0,
          shadowOpacity: 0,
        },
        headerTintColor: theme.colors.white,
        headerTitleStyle: {
          fontFamily: theme.typography.fonts.semiBold,
          fontSize: theme.typography.sizes.lg,
        },
        headerBackTitleVisible: false,
        cardStyle: { backgroundColor: theme.colors.background.secondary },
      }}
    >
      <WorkOrderStack.Screen 
        name="WorkOrderList" 
        component={WorkOrderListScreen}
        options={{ title: 'Ordres de Travail' }}
      />
      <WorkOrderStack.Screen 
        name="WorkOrderDetails" 
        component={WorkOrderDetailsScreen}
        options={{ title: 'Détails OT' }}
      />
    </WorkOrderStack.Navigator>
  );
};

// ============================================================================
// TAB NAVIGATOR
// ============================================================================

const MainNavigator: React.FC = () => {
  return (
    <MainTab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarIcon: ({ focused, color, size }) => {
          let iconName = 'home';

          switch (route.name) {
            case 'Dashboard':
              iconName = 'home';
              break;
            case 'WorkOrders':
              iconName = 'clipboard';
              break;
            case 'Scan':
              iconName = 'camera';
              break;
            case 'Profile':
              iconName = 'user';
              break;
          }

          return (
            <View style={[styles.tabIconContainer, focused && styles.tabIconFocused]}>
              <Icon name={iconName} size={size} color={color} />
              {focused && <View style={styles.tabIndicator} />}
            </View>
          );
        },
        tabBarActiveTintColor: theme.colors.primary[500],
        tabBarInactiveTintColor: theme.colors.gray[400],
        tabBarStyle: {
          backgroundColor: theme.colors.white,
          borderTopWidth: 1,
          borderTopColor: theme.colors.border.light,
          height: Platform.OS === 'ios' ? 85 : 65,
          paddingBottom: Platform.OS === 'ios' ? 25 : 10,
          paddingTop: 10,
          ...theme.shadows.lg,
        },
        tabBarLabelStyle: {
          fontFamily: theme.typography.fonts.medium,
          fontSize: theme.typography.sizes.xs,
          marginTop: 4,
        },
        tabBarItemStyle: {
          paddingVertical: 5,
        },
      })}
    >
      <MainTab.Screen 
        name="Dashboard" 
        component={DashboardScreen}
        options={{ tabBarLabel: 'Accueil' }}
      />
      <MainTab.Screen 
        name="WorkOrders" 
        component={WorkOrderNavigator}
        options={{ tabBarLabel: 'Tâches' }}
      />
      <MainTab.Screen 
        name="Scan" 
        component={AssetScanScreen}
        options={{ 
          tabBarLabel: 'Scanner',
          tabBarButton: (props) => (
            <View style={styles.scanButtonContainer}>
              <View style={styles.scanButton}>
                <Icon name="camera" size={24} color={theme.colors.white} />
              </View>
            </View>
          ),
        }}
      />
      <MainTab.Screen 
        name="Profile" 
        component={ProfileScreen}
        options={{ tabBarLabel: 'Profil' }}
      />
    </MainTab.Navigator>
  );
};

// ============================================================================
// ROOT NAVIGATOR
// ============================================================================

const RootNavigator: React.FC = () => {
  return (
    <RootStack.Navigator 
      screenOptions={{ 
        headerShown: false,
        presentation: 'modal',
        cardStyle: { backgroundColor: theme.colors.background.primary },
      }}
    >
      <RootStack.Screen name="Main" component={MainNavigator} />
      <RootStack.Screen 
        name="Settings" 
        component={SettingsScreen}
        options={{
          headerShown: true,
          title: 'Paramètres',
          headerStyle: {
            backgroundColor: theme.colors.primary[500],
          },
          headerTintColor: theme.colors.white,
          headerTitleStyle: {
            fontFamily: theme.typography.fonts.semiBold,
          },
        }}
      />
      <RootStack.Screen 
        name="Sync" 
        component={SyncScreen}
        options={{
          headerShown: true,
          title: 'Synchronisation',
          headerStyle: {
            backgroundColor: theme.colors.primary[500],
          },
          headerTintColor: theme.colors.white,
          headerTitleStyle: {
            fontFamily: theme.typography.fonts.semiBold,
          },
        }}
      />
    </RootStack.Navigator>
  );
};

// ============================================================================
// APP NAVIGATOR PRINCIPAL
// ============================================================================

const AppNavigator: React.FC = () => {
  const isAuthenticated = useAppSelector(selectIsAuthenticated);

  return (
    <NavigationContainer
      theme={{
        dark: false,
        colors: {
          primary: theme.colors.primary[500],
          background: theme.colors.background.primary,
          card: theme.colors.white,
          text: theme.colors.text.primary,
          border: theme.colors.border.light,
          notification: theme.colors.error[500],
        },
      }}
    >
      {isAuthenticated ? <RootNavigator /> : <AuthNavigator />}
    </NavigationContainer>
  );
};

// ============================================================================
// STYLES
// ============================================================================

const styles = StyleSheet.create({
  tabIconContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    paddingVertical: 2,
  },
  tabIconFocused: {
    transform: [{ scale: 1.1 }],
  },
  tabIndicator: {
    position: 'absolute',
    bottom: -8,
    width: 4,
    height: 4,
    borderRadius: 2,
    backgroundColor: theme.colors.primary[500],
  },
  scanButtonContainer: {
    top: -20,
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1,
  },
  scanButton: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: theme.colors.primary[500],
    justifyContent: 'center',
    alignItems: 'center',
    ...theme.shadows.lg,
    borderWidth: 4,
    borderColor: theme.colors.white,
  },
});

export default AppNavigator;