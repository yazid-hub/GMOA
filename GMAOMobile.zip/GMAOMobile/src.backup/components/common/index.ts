// src/components/common/index.ts
import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  Modal,
  ScrollView,
  StyleSheet,
  ViewStyle,
  TextStyle,
  TouchableOpacityProps,
  TextInputProps,
} from 'react-native';
import { theme } from '../../styles/theme';

// ============================================================================
// BOUTON MODERNE
// ============================================================================

interface ButtonProps extends TouchableOpacityProps {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  children: React.ReactNode;
  fullWidth?: boolean;
}

export const Button: React.FC<ButtonProps> = ({
  variant = 'primary',
  size = 'md',
  loading = false,
  leftIcon,
  rightIcon,
  children,
  fullWidth = false,
  disabled,
  style,
  ...props
}) => {
  const buttonStyles = [
    styles.buttonBase,
    styles[`button${variant.charAt(0).toUpperCase() + variant.slice(1)}` as keyof typeof styles],
    styles[`buttonSize${size.toUpperCase()}` as keyof typeof styles],
    fullWidth && styles.buttonFullWidth,
    disabled && styles.buttonDisabled,
    style,
  ];

  const textStyles = [
    styles.buttonTextBase,
    styles[`buttonText${variant.charAt(0).toUpperCase() + variant.slice(1)}` as keyof typeof styles],
    styles[`buttonTextSize${size.toUpperCase()}` as keyof typeof styles],
    disabled && styles.buttonTextDisabled,
  ];

  return (
    <TouchableOpacity
      style={buttonStyles}
      disabled={disabled || loading}
      activeOpacity={0.8}
      {...props}
    >
      <View style={styles.buttonContent}>
        {loading ? (
          <ActivityIndicator
            size="small"
            color={variant === 'primary' ? theme.colors.white : theme.colors.primary[500]}
            style={styles.buttonLoader}
          />
        ) : (
          <>
            {leftIcon && <View style={styles.buttonIconLeft}>{leftIcon}</View>}
            <Text style={textStyles}>{children}</Text>
            {rightIcon && <View style={styles.buttonIconRight}>{rightIcon}</View>}
          </>
        )}
      </View>
    </TouchableOpacity>
  );
};

// ============================================================================
// CARTE MODERNE
// ============================================================================

interface CardProps {
  children: React.ReactNode;
  variant?: 'default' | 'elevated' | 'outlined';
  padding?: keyof typeof theme.spacing;
  style?: ViewStyle;
  onPress?: () => void;
}

export const Card: React.FC<CardProps> = ({
  children,
  variant = 'default',
  padding = 4,
  style,
  onPress,
}) => {
  const cardStyles = [
    styles.cardBase,
    styles[`card${variant.charAt(0).toUpperCase() + variant.slice(1)}` as keyof typeof styles],
    { padding: theme.spacing[padding] },
    style,
  ];

  if (onPress) {
    return (
      <TouchableOpacity style={cardStyles} onPress={onPress} activeOpacity={0.9}>
        {children}
      </TouchableOpacity>
    );
  }

  return <View style={cardStyles}>{children}</View>;
};

// ============================================================================
// INPUT MODERNE
// ============================================================================

interface InputProps extends TextInputProps {
  label?: string;
  error?: string;
  hint?: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  variant?: 'default' | 'filled' | 'outlined';
  size?: 'sm' | 'md' | 'lg';
}

export const Input: React.FC<InputProps> = ({
  label,
  error,
  hint,
  leftIcon,
  rightIcon,
  variant = 'outlined',
  size = 'md',
  style,
  ...props
}) => {
  const inputContainerStyles = [
    styles.inputContainer,
    styles[`input${variant.charAt(0).toUpperCase() + variant.slice(1)}` as keyof typeof styles],
    styles[`inputSize${size.toUpperCase()}` as keyof typeof styles],
    error && styles.inputError,
  ];

  const inputStyles = [
    styles.inputBase,
    leftIcon && styles.inputWithLeftIcon,
    rightIcon && styles.inputWithRightIcon,
    style,
  ];

  return (
    <View style={styles.inputWrapper}>
      {label && <Text style={styles.inputLabel}>{label}</Text>}
      <View style={inputContainerStyles}>
        {leftIcon && <View style={styles.inputIconLeft}>{leftIcon}</View>}
        <TextInput
          style={inputStyles}
          placeholderTextColor={theme.colors.text.tertiary}
          {...props}
        />
        {rightIcon && <View style={styles.inputIconRight}>{rightIcon}</View>}
      </View>
      {error && <Text style={styles.inputErrorText}>{error}</Text>}
      {hint && !error && <Text style={styles.inputHint}>{hint}</Text>}
    </View>
  );
};

// ============================================================================
// BADGE MODERNE
// ============================================================================

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'default' | 'primary' | 'secondary' | 'success' | 'warning' | 'error';
  size?: 'sm' | 'md' | 'lg';
  style?: ViewStyle;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'default',
  size = 'md',
  style,
}) => {
  const badgeStyles = [
    styles.badgeBase,
    styles[`badge${variant.charAt(0).toUpperCase() + variant.slice(1)}` as keyof typeof styles],
    styles[`badgeSize${size.toUpperCase()}` as keyof typeof styles],
    style,
  ];

  const textStyles = [
    styles.badgeTextBase,
    styles[`badgeText${variant.charAt(0).toUpperCase() + variant.slice(1)}` as keyof typeof styles],
    styles[`badgeTextSize${size.toUpperCase()}` as keyof typeof styles],
  ];

  return (
    <View style={badgeStyles}>
      <Text style={textStyles}>{children}</Text>
    </View>
  );
};

// ============================================================================
// LOADER MODERNE
// ============================================================================

interface LoaderProps {
  size?: 'small' | 'large';
  color?: string;
  text?: string;
  overlay?: boolean;
}

export const Loader: React.FC<LoaderProps> = ({
  size = 'large',
  color = theme.colors.primary[500],
  text,
  overlay = false,
}) => {
  const content = (
    <View style={[styles.loaderContainer, overlay && styles.loaderOverlay]}>
      <View style={styles.loaderContent}>
        <ActivityIndicator size={size} color={color} />
        {text && <Text style={styles.loaderText}>{text}</Text>}
      </View>
    </View>
  );

  if (overlay) {
    return (
      <Modal transparent visible animationType="fade">
        {content}
      </Modal>
    );
  }

  return content;
};

// ============================================================================
// MODAL MODERNE
// ============================================================================

interface ModalProps {
  visible: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'full';
  animationType?: 'slide' | 'fade' | 'none';
}

export const ModernModal: React.FC<ModalProps> = ({
  visible,
  onClose,
  title,
  children,
  size = 'md',
  animationType = 'slide',
}) => {
  return (
    <Modal
      visible={visible}
      transparent
      animationType={animationType}
      onRequestClose={onClose}
    >
      <View style={styles.modalOverlay}>
        <TouchableOpacity
          style={styles.modalBackdrop}
          activeOpacity={1}
          onPress={onClose}
        />
        <View style={[styles.modalContainer, styles[`modalSize${size.toUpperCase()}` as keyof typeof styles]]}>
          {title && (
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{title}</Text>
              <TouchableOpacity onPress={onClose} style={styles.modalCloseButton}>
                <Text style={styles.modalCloseText}>✕</Text>
              </TouchableOpacity>
            </View>
          )}
          <ScrollView style={styles.modalContent} showsVerticalScrollIndicator={false}>
            {children}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
};

// ============================================================================
// SEPARATOR
// ============================================================================

interface SeparatorProps {
  orientation?: 'horizontal' | 'vertical';
  size?: number;
  color?: string;
  style?: ViewStyle;
}

export const Separator: React.FC<SeparatorProps> = ({
  orientation = 'horizontal',
  size = 1,
  color = theme.colors.border.light,
  style,
}) => {
  const separatorStyle = [
    orientation === 'horizontal'
      ? { height: size, backgroundColor: color }
      : { width: size, backgroundColor: color },
    style,
  ];

  return <View style={separatorStyle} />;
};

// ============================================================================
// STYLES
// ============================================================================

const styles = StyleSheet.create({
  // Button styles
  buttonBase: {
    borderRadius: theme.borderRadius.md,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    ...theme.shadows.sm,
  },
  buttonPrimary: {
    backgroundColor: theme.colors.primary[500],
  },
  buttonSecondary: {
    backgroundColor: theme.colors.secondary[500],
  },
  buttonOutline: {
    backgroundColor: theme.colors.transparent,
    borderWidth: 1.5,
    borderColor: theme.colors.primary[500],
  },
  buttonGhost: {
    backgroundColor: theme.colors.transparent,
  },
  buttonDanger: {
    backgroundColor: theme.colors.error[500],
  },
  buttonSizeSM: {
    paddingHorizontal: theme.spacing[3],
    paddingVertical: theme.spacing[2],
    minHeight: 36,
  },
  buttonSizeMD: {
    paddingHorizontal: theme.spacing[4],
    paddingVertical: theme.spacing[3],
    minHeight: 44,
  },
  buttonSizeLG: {
    paddingHorizontal: theme.spacing[6],
    paddingVertical: theme.spacing[4],
    minHeight: 52,
  },
  buttonFullWidth: {
    width: '100%',
  },
  buttonDisabled: {
    opacity: 0.5,
  },
  buttonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonTextBase: {
    fontFamily: theme.typography.fonts.semiBold,
    textAlign: 'center',
  },
  buttonTextPrimary: {
    color: theme.colors.white,
  },
  buttonTextSecondary: {
    color: theme.colors.white,
  },
  buttonTextOutline: {
    color: theme.colors.primary[500],
  },
  buttonTextGhost: {
    color: theme.colors.primary[500],
  },
  buttonTextDanger: {
    color: theme.colors.white,
  },
  buttonTextSizeSM: {
    fontSize: theme.typography.sizes.sm,
  },
  buttonTextSizeMD: {
    fontSize: theme.typography.sizes.base,
  },
  buttonTextSizeLG: {
    fontSize: theme.typography.sizes.lg,
  },
  buttonTextDisabled: {
    opacity: 0.7,
  },
  buttonLoader: {
    marginRight: theme.spacing[2],
  },
  buttonIconLeft: {
    marginRight: theme.spacing[2],
  },
  buttonIconRight: {
    marginLeft: theme.spacing[2],
  },

  // Card styles
  cardBase: {
    borderRadius: theme.borderRadius.lg,
    backgroundColor: theme.colors.white,
  },
  cardDefault: {
    ...theme.shadows.sm,
  },
  cardElevated: {
    ...theme.shadows.md,
  },
  cardOutlined: {
    borderWidth: 1,
    borderColor: theme.colors.border.light,
  },

  // Input styles
  inputWrapper: {
    marginBottom: theme.spacing[1],
  },
  inputLabel: {
    fontSize: theme.typography.sizes.sm,
    fontFamily: theme.typography.fonts.medium,
    color: theme.colors.text.primary,
    marginBottom: theme.spacing[1],
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: theme.borderRadius.md,
  },
  inputDefault: {
    backgroundColor: theme.colors.background.secondary,
    borderWidth: 1,
    borderColor: theme.colors.border.light,
  },
  inputFilled: {
    backgroundColor: theme.colors.background.tertiary,
  },
  inputOutlined: {
    backgroundColor: theme.colors.white,
    borderWidth: 1.5,
    borderColor: theme.colors.border.medium,
  },
  inputSizeSM: {
    minHeight: 36,
  },
  inputSizeMD: {
    minHeight: 44,
  },
  inputSizeLG: {
    minHeight: 52,
  },
  inputError: {
    borderColor: theme.colors.error[500],
  },
  inputBase: {
    flex: 1,
    fontSize: theme.typography.sizes.base,
    fontFamily: theme.typography.fonts.regular,
    color: theme.colors.text.primary,
    paddingHorizontal: theme.spacing[3],
  },
  inputWithLeftIcon: {
    paddingLeft: 0,
  },
  inputWithRightIcon: {
    paddingRight: 0,
  },
  inputIconLeft: {
    paddingLeft: theme.spacing[3],
    paddingRight: theme.spacing[2],
  },
  inputIconRight: {
    paddingRight: theme.spacing[3],
    paddingLeft: theme.spacing[2],
  },
  inputErrorText: {
    fontSize: theme.typography.sizes.sm,
    color: theme.colors.error[500],
    marginTop: theme.spacing[1],
    fontFamily: theme.typography.fonts.regular,
  },
  inputHint: {
    fontSize: theme.typography.sizes.sm,
    color: theme.colors.text.tertiary,
    marginTop: theme.spacing[1],
    fontFamily: theme.typography.fonts.regular,
  },

  // Badge styles
  badgeBase: {
    borderRadius: theme.borderRadius.full,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'flex-start',
  },
  badgeDefault: {
    backgroundColor: theme.colors.gray[100],
  },
  badgePrimary: {
    backgroundColor: theme.colors.primary[500],
  },
  badgeSecondary: {
    backgroundColor: theme.colors.secondary[500],
  },
  badgeSuccess: {
    backgroundColor: theme.colors.success[500],
  },
  badgeWarning: {
    backgroundColor: theme.colors.warning[500],
  },
  badgeError: {
    backgroundColor: theme.colors.error[500],
  },
  badgeSizeSM: {
    paddingHorizontal: theme.spacing[2],
    paddingVertical: theme.spacing[1],
  },
  badgeSizeMD: {
    paddingHorizontal: theme.spacing[3],
    paddingVertical: theme.spacing[1],
  },
  badgeSizeLG: {
    paddingHorizontal: theme.spacing[4],
    paddingVertical: theme.spacing[2],
  },
  badgeTextBase: {
    fontFamily: theme.typography.fonts.semiBold,
  },
  badgeTextDefault: {
    color: theme.colors.text.primary,
  },
  badgeTextPrimary: {
    color: theme.colors.white,
  },
  badgeTextSecondary: {
    color: theme.colors.white,
  },
  badgeTextSuccess: {
    color: theme.colors.white,
  },
  badgeTextWarning: {
    color: theme.colors.white,
  },
  badgeTextError: {
    color: theme.colors.white,
  },
  badgeTextSizeSM: {
    fontSize: theme.typography.sizes.xs,
  },
  badgeTextSizeMD: {
    fontSize: theme.typography.sizes.sm,
  },
  badgeTextSizeLG: {
    fontSize: theme.typography.sizes.base,
  },

  // Loader styles
  loaderContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  loaderOverlay: {
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  loaderContent: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: theme.colors.white,
    padding: theme.spacing[6],
    borderRadius: theme.borderRadius.xl,
    ...theme.shadows.lg,
  },
  loaderText: {
    marginTop: theme.spacing[3],
    fontSize: theme.typography.sizes.base,
    color: theme.colors.text.secondary,
    fontFamily: theme.typography.fonts.medium,
  },

  // Modal styles
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalBackdrop: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContainer: {
    backgroundColor: theme.colors.white,
    borderRadius: theme.borderRadius.xl,
    ...theme.shadows.xl,
    maxHeight: '90%',
  },
  modalSizeSM: {
    width: '80%',
    maxWidth: 300,
  },
  modalSizeMD: {
    width: '90%',
    maxWidth: 400,
  },
  modalSizeLG: {
    width: '95%',
    maxWidth: 600,
  },
  modalSizeFULL: {
    width: '100%',
    height: '100%',
    borderRadius: 0,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: theme.spacing[4],
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border.light,
  },
  modalTitle: {
    fontSize: theme.typography.sizes.lg,
    fontFamily: theme.typography.fonts.semiBold,
    color: theme.colors.text.primary,
    flex: 1,
  },
  modalCloseButton: {
    padding: theme.spacing[1],
  },
  modalCloseText: {
    fontSize: theme.typography.sizes.xl,
    color: theme.colors.text.tertiary,
  },
  modalContent: {
    padding: theme.spacing[4],
  },
});